import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").unique(),
  onboardingComplete: boolean("onboarding_complete").default(false),
});

export const brands = pgTable("brands", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  targetAudience: text("target_audience"),
  uniqueValue: text("unique_value"),
  keywords: text("keywords").array(),
  industry: text("industry"),
  brandType: text("brand_type"),
  reach: integer("reach").default(0),
  videos: integer("videos").default(0),
  performing: integer("performing").default(0),
  stagnated: integer("stagnated").default(0),
  needsBoost: integer("needs_boost").default(0),
  inactive: integer("inactive").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  brandId: integer("brand_id").references(() => brands.id),
  title: text("title").notNull(),
  channel: text("channel").notNull(),
  platform: text("platform").default("youtube"),
  url: text("url"),
  description: text("description"),
  views: integer("views").default(0),
  likes: integer("likes").default(0),
  status: text("status").default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").references(() => videos.id),
  brandId: integer("brand_id").references(() => brands.id),
  text: text("text").notNull(),
  tone: text("tone"),
  personality: text("personality"),
  authenticityScore: integer("authenticity_score"),
  qualityScore: integer("quality_score"),
  relevanceScore: integer("relevance_score"),
  approved: boolean("approved").default(false),
  posted: boolean("posted").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Manual insert schemas to avoid drizzle-zod compatibility issues
export const insertUserSchema = z.object({
  username: z.string(),
  password: z.string(),
  email: z.string().optional(),
  onboardingComplete: z.boolean().optional(),
});

export const insertBrandSchema = z.object({
  userId: z.number().optional(),
  name: z.string(),
  description: z.string().optional(),
  targetAudience: z.string().optional(),
  uniqueValue: z.string().optional(),
  keywords: z.array(z.string()).optional(),
  industry: z.string().optional(),
  brandType: z.string().optional(),
  reach: z.number().optional(),
  videos: z.number().optional(),
  performing: z.number().optional(),
  stagnated: z.number().optional(),
  needsBoost: z.number().optional(),
  inactive: z.number().optional(),
});

export const insertVideoSchema = z.object({
  brandId: z.number().optional(),
  title: z.string(),
  channel: z.string(),
  platform: z.string().optional(),
  url: z.string().optional(),
  description: z.string().optional(),
  views: z.number().optional(),
  likes: z.number().optional(),
  status: z.string().optional(),
});

export const insertCommentSchema = z.object({
  videoId: z.number().optional(),
  brandId: z.number().optional(),
  text: z.string(),
  tone: z.string().optional(),
  personality: z.string().optional(),
  authenticityScore: z.number().optional(),
  qualityScore: z.number().optional(),
  relevanceScore: z.number().optional(),
  approved: z.boolean().optional(),
  posted: z.boolean().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertBrand = z.infer<typeof insertBrandSchema>;
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type User = typeof users.$inferSelect;
export type Brand = typeof brands.$inferSelect;
export type Video = typeof videos.$inferSelect;
export type Comment = typeof comments.$inferSelect;
