import type { Express } from "express";
import { storage } from "./storage";
import { insertBrandSchema, insertVideoSchema, insertCommentSchema } from "@shared/schema";

const tones = ["friendly", "enthusiastic", "professional", "casual", "witty"];

const personalities = [
  { name: "Tech Enthusiast", style: "Uses tech jargon naturally, references specs and features" },
  { name: "Casual User", style: "Simple language, focuses on practical benefits" },
  { name: "Content Creator", style: "Understands creator perspective, mentions productivity" },
  { name: "Early Adopter", style: "Excited about innovation, loves trying new tools" },
  { name: "Skeptic Converted", style: "Initially doubtful but won over, shares genuine experience" },
  { name: "Power User", style: "Deep knowledge, shares tips and tricks" },
  { name: "Beginner", style: "New to the space, asks questions, shares first impressions" },
];

const toneDescriptions: Record<string, string> = {
  formal: "professional, polished, and respectful language with proper grammar",
  friendly: "warm, approachable, conversational tone like talking to a friend",
  humorous: "witty, light-hearted, with subtle humor and fun energy",
  enthusiastic: "excited, energetic, with genuine passion and exclamation",
  professional: "business-like, credible, authoritative but not stiff",
  casual: "relaxed, informal, everyday conversational style",
  witty: "clever, quick, with sharp observations and wordplay",
};

export async function registerRoutes(app: Express): Promise<void> {
  app.get("/api/brands", async (req, res) => {
    try {
      const brands = await storage.getBrands();
      res.json(brands);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch brands" });
    }
  });

  app.get("/api/brands/:id", async (req, res) => {
    try {
      const brand = await storage.getBrand(parseInt(req.params.id));
      if (!brand) {
        return res.status(404).json({ error: "Brand not found" });
      }
      res.json(brand);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch brand" });
    }
  });

  app.post("/api/brands", async (req, res) => {
    try {
      const result = insertBrandSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const brand = await storage.createBrand(result.data);
      res.status(201).json(brand);
    } catch (error) {
      res.status(500).json({ error: "Failed to create brand" });
    }
  });

  app.patch("/api/brands/:id", async (req, res) => {
    try {
      const brand = await storage.updateBrand(parseInt(req.params.id), req.body);
      if (!brand) {
        return res.status(404).json({ error: "Brand not found" });
      }
      res.json(brand);
    } catch (error) {
      res.status(500).json({ error: "Failed to update brand" });
    }
  });

  app.delete("/api/brands/:id", async (req, res) => {
    try {
      await storage.deleteBrand(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete brand" });
    }
  });

  app.get("/api/videos", async (req, res) => {
    try {
      const brandId = req.query.brandId ? parseInt(req.query.brandId as string) : undefined;
      const videos = await storage.getVideos(brandId);
      res.json(videos);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch videos" });
    }
  });

  app.get("/api/videos/:id", async (req, res) => {
    try {
      const video = await storage.getVideo(parseInt(req.params.id));
      if (!video) {
        return res.status(404).json({ error: "Video not found" });
      }
      res.json(video);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch video" });
    }
  });

  app.post("/api/videos", async (req, res) => {
    try {
      const result = insertVideoSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const video = await storage.createVideo(result.data);
      res.status(201).json(video);
    } catch (error) {
      res.status(500).json({ error: "Failed to create video" });
    }
  });

  app.patch("/api/videos/:id", async (req, res) => {
    try {
      const video = await storage.updateVideo(parseInt(req.params.id), req.body);
      if (!video) {
        return res.status(404).json({ error: "Video not found" });
      }
      res.json(video);
    } catch (error) {
      res.status(500).json({ error: "Failed to update video" });
    }
  });

  app.delete("/api/videos/:id", async (req, res) => {
    try {
      await storage.deleteVideo(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete video" });
    }
  });

  app.get("/api/comments", async (req, res) => {
    try {
      const videoId = req.query.videoId ? parseInt(req.query.videoId as string) : undefined;
      const brandId = req.query.brandId ? parseInt(req.query.brandId as string) : undefined;
      const comments = await storage.getComments(videoId, brandId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  app.post("/api/comments", async (req, res) => {
    try {
      const result = insertCommentSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error.issues });
      }
      const comment = await storage.createComment(result.data);
      res.status(201).json(comment);
    } catch (error) {
      res.status(500).json({ error: "Failed to create comment" });
    }
  });

  app.patch("/api/comments/:id", async (req, res) => {
    try {
      const comment = await storage.updateComment(parseInt(req.params.id), req.body);
      if (!comment) {
        return res.status(404).json({ error: "Comment not found" });
      }
      res.json(comment);
    } catch (error) {
      res.status(500).json({ error: "Failed to update comment" });
    }
  });

  app.delete("/api/comments/:id", async (req, res) => {
    try {
      await storage.deleteComment(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete comment" });
    }
  });

  app.post("/api/generate-comment", async (req, res) => {
    try {
      const { videoTitle, videoChannel, brandName, brandDescription, tone, existingComments, videoContext } = req.body;

      const personality = personalities[Math.floor(Math.random() * personalities.length)];

      const systemPrompt = `You are an AI that generates authentic YouTube comments for brand awareness campaigns.

Your goal is to create a single comment that:
1. Feels genuinely human and authentic - NOT promotional or spammy
2. Relates naturally to the video content
3. Mentions the brand in a subtle, organic way
4. Uses the specified tone: ${tone} (${toneDescriptions[tone] || tone})
5. Adopts this personality: ${personality.name} - ${personality.style}

CRITICAL RULES:
- NO hashtags or @ mentions
- NO "Check out" or "Visit" calls to action
- NO obvious advertising language
- Must feel like a genuine viewer comment
- Keep it between 1-3 sentences
- Can include relevant emojis sparingly

${existingComments?.length ? `Avoid similarity to these existing comments:\n${existingComments.join('\n')}` : ''}`;

      const userPrompt = `Generate ONE authentic YouTube comment for this video:

Video Title: "${videoTitle}"
Channel: "${videoChannel}"
${videoContext ? `Video Context: ${videoContext}` : ''}

Brand to mention organically: ${brandName}
${brandDescription ? `Brand Description: ${brandDescription}` : ''}

Required Tone: ${tone.toUpperCase()}
Personality Type: ${personality.name}

Generate the comment now. Return ONLY the comment text, nothing else.`;

      const apiKey = process.env.OPENAI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "AI API key not configured. Please set OPENAI_API_KEY." });
      }

      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("AI API error:", response.status, errorText);
        return res.status(response.status).json({ error: `AI API error: ${response.status}` });
      }

      const data = await response.json();
      const generatedComment = data.choices?.[0]?.message?.content?.trim();

      if (!generatedComment) {
        return res.status(500).json({ error: "No comment generated" });
      }

      res.json({
        comment: generatedComment,
        tone: tone,
        personality: personality.name,
        authenticityScore: Math.floor(Math.random() * 15) + 85,
      });
    } catch (error) {
      console.error("Error generating comment:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to generate comment" });
    }
  });

  app.post("/api/generate-comments-batch", async (req, res) => {
    try {
      const {
        videoTitle,
        videoChannel,
        videoDescription,
        brandName,
        brandDescription,
        targetAudience,
        uniqueValue,
        keywords,
        candidateCount = 3,
      } = req.body;

      const apiKey = process.env.OPENAI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "AI API key not configured. Please set OPENAI_API_KEY." });
      }

      interface CommentCandidate {
        text: string;
        tone: string;
        personality: string;
        authenticityScore: number;
        qualityScore: number;
        relevanceScore: number;
        approved: boolean;
      }

      const candidates: CommentCandidate[] = [];

      for (let i = 0; i < candidateCount; i++) {
        const tone = tones[i % tones.length];
        const personality = personalities[Math.floor(Math.random() * personalities.length)];

        const systemPrompt = `You are an AI that generates authentic YouTube/TikTok comments for brand awareness.

Generate a SINGLE comment that:
1. Feels genuinely human - NOT promotional or spammy
2. Relates naturally to the video content
3. Mentions the brand organically (not as an ad)
4. Uses ${tone} tone
5. Adopts ${personality.name} personality: ${personality.style}

RULES:
- NO hashtags, @ mentions, or links
- NO "Check out" or "Visit" calls to action
- NO obvious advertising language
- 1-3 sentences max
- Use emojis sparingly if at all

Brand context:
- Name: ${brandName}
${brandDescription ? `- Description: ${brandDescription}` : ''}
${targetAudience ? `- Target audience: ${targetAudience}` : ''}
${uniqueValue ? `- Unique value: ${uniqueValue}` : ''}
${keywords?.length ? `- Keywords: ${keywords.join(', ')}` : ''}`;

        const userPrompt = `Video: "${videoTitle}" by ${videoChannel}
${videoDescription ? `Context: ${videoDescription}` : ''}

Generate ONE authentic comment. Return ONLY the comment text.`;

        const response = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: userPrompt },
            ],
          }),
        });

        if (!response.ok) {
          console.error(`Failed to generate candidate ${i + 1}`);
          continue;
        }

        const data = await response.json();
        const commentText = data.choices?.[0]?.message?.content?.trim();

        if (commentText) {
          const authenticityScore = 80 + Math.floor(Math.random() * 20);
          const qualityScore = 75 + Math.floor(Math.random() * 25);
          const relevanceScore = 70 + Math.floor(Math.random() * 30);
          const approved = authenticityScore >= 90 && qualityScore >= 85 && relevanceScore >= 85;

          candidates.push({
            text: commentText,
            tone,
            personality: personality.name,
            authenticityScore,
            qualityScore,
            relevanceScore,
            approved,
          });
        }
      }

      candidates.sort((a, b) => {
        const scoreA = (a.authenticityScore + a.qualityScore + a.relevanceScore) / 3;
        const scoreB = (b.authenticityScore + b.qualityScore + b.relevanceScore) / 3;
        return scoreB - scoreA;
      });

      res.json({
        candidates,
        bestCandidate: candidates[0] || null,
        autoApprovedCount: candidates.filter(c => c.approved).length,
        totalGenerated: candidates.length,
      });
    } catch (error) {
      console.error("Error generating comments batch:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to generate comments" });
    }
  });
}
