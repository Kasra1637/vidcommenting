# Rumora - AI-Powered Brand Awareness Platform

## Overview
Rumora is an AI-powered brand awareness platform that helps brands discover relevant YouTube/TikTok videos and automatically generate, approve, and post authentic comments for brand awareness campaigns.

## Project Architecture

### Stack
- **Frontend**: React + TypeScript + Vite + TailwindCSS + shadcn/ui
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Routing**: wouter (frontend)

### Directory Structure
```
├── client/               # Frontend React application
│   ├── src/
│   │   ├── components/   # Reusable UI components
│   │   ├── pages/        # Page components
│   │   ├── hooks/        # Custom React hooks
│   │   ├── lib/          # Utilities and helpers
│   │   └── App.tsx       # Main app with routes
│   └── index.html
├── server/               # Backend Express server
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   ├── storage.ts        # Database storage interface
│   ├── db.ts             # Database connection
│   └── vite.ts           # Vite dev server integration
├── shared/               # Shared types and schemas
│   └── schema.ts         # Drizzle schema definitions
└── drizzle.config.ts     # Drizzle configuration
```

### Database Schema
- **users**: User accounts with email authentication
- **brands**: Brand profiles with AI discovery settings
- **videos**: Discovered videos from YouTube/TikTok
- **comments**: Generated comments with status tracking

### Key Features
1. **AI Discovery**: Automatically discover trending videos with viral prediction scores, growth analysis, and engagement metrics
2. **Campaign Management**: Create and manage automated 24/7 brand awareness campaigns with AI agents
3. **Comment Generation**: AI-generated authentic comments using OpenAI API
4. **Comment Position Monitoring**: Real-time tracking of comment positions with auto-boost functionality
5. **Multi-Platform Support**: YouTube and TikTok video discovery and comment posting
6. **AI Agent Activity Feed**: Live feed showing AI automation status (discoveries, generations, postings, boosts)
7. **Analytics Dashboard**: Track reach, performance, and engagement

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (automatically provided by Replit)
- `OPENAI_API_KEY`: OpenAI API key for comment generation (needs to be added as secret)

### Running the Application
The application runs with `npm run dev` which starts both the Express backend and Vite frontend on port 5000.

### Database Commands
- `npm run db:push` - Push schema changes to database
- `npm run db:studio` - Open Drizzle Studio for database management

## Recent Changes
- Added AI Discovery page with viral prediction scores, growth trajectories, trending signals, and video selection
- Added Campaigns page for managing automated 24/7 campaigns with real-time AI agent status
- Implemented Comment Position Monitor component with auto-boost functionality
- Added AI Agent Activity Feed showing live automation status (discovering, generating, posting, monitoring)
- Integrated platform badges (YouTube/TikTok) throughout Videos, Discovery, Campaigns pages
- Updated sidebar navigation with AI Discovery and Campaigns pages
- Migrated from Supabase/Lovable to Replit environment
- Converted routing from react-router-dom to wouter
- Replaced Supabase Edge Functions with Express API routes
- Set up PostgreSQL database with Drizzle ORM

## User Preferences
- Clean, warm design with gradient accents
- Dark sidebar with light content area
- Modern UI using shadcn/ui components
